#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>

#define SIZE_SMALL_A 0xc0
#define SIZE_SMALL_B 0xf0
#define SIZE_BIG_A   0x500
#define SIZE_BIG_B   0x510
#define MAX 0x10

char *heaplist[MAX];
uintptr_t heap_base;

void init() {
    setvbuf(stdin, 0, 2, 0);
    setvbuf(stdout, 0, 2, 0);
    setvbuf(stderr, 0, 2, 0);
}

void wisdom(char *ptr) {
    if (ptr && !heap_base) {
        heap_base = (uintptr_t)ptr & ~0xfffULL;
    }
}

int times(uintptr_t ptr) {
    uintptr_t heap_end = (uintptr_t)sbrk(0);

    if (!ptr) {
        return 1;
    }
    if (!heap_base) {
        return 1;
    }
    return ptr >= heap_base && ptr < heap_end;
}

void faded(char *ptr, ssize_t len) {
    if (len <= SIZE_SMALL_A + 0x18) {
        return;
    }

    uintptr_t next_size = *(uintptr_t *)(ptr + SIZE_SMALL_A + 0x8) & ~0xfULL;
    if (next_size < 0x20 || next_size > SIZE_BIG_B + 0x10) {
        return;
    }

    uintptr_t next_bk = *(uintptr_t *)(ptr + SIZE_SMALL_A + 0x18);
    if (!times(next_bk)) {
        _exit(1);
    }
}

int getnum() {
    int num;
    scanf("%d", &num);
    return num;
}

void menu() {
    puts("1. add");
    puts("2. delete");
    puts("3. edit");
    printf("Your choice > ");
}

int getindex() {
    printf("input index: ");
    return getnum();
}

void add() {
    int index = getindex();
    if (index < 0 || index >= MAX) {
        puts("Invalid index!");
        _exit(1);
    }
    printf("1. 0xd0\n2. 0xa0\n3. 0x510\n4. 0x520\nchoice: ");
    int choice = getnum();
    switch(choice) {
        case 1:
            heaplist[index] = (char *)malloc(SIZE_SMALL_A);
            break;
        case 2:
            heaplist[index] = (char *)malloc(SIZE_SMALL_B);
            break;
        case 3:
            heaplist[index] = (char *)malloc(SIZE_BIG_A);
            break;
        case 4:
            heaplist[index] = (char *)malloc(SIZE_BIG_B);
            break;
        default:
            puts("Invalid choice!");
            return;
    }
    wisdom(heaplist[index]);
    puts("Chunk allocated.");
}

void delete() {
    int index = getindex();
    if (index < 0 || index >= MAX) {
        puts("Invalid index!");
        _exit(1);
    }
    if (!heaplist[index]) {
        puts("Empty.");
        return;
    }
    free(heaplist[index]);
    heaplist[index] = NULL;
    puts("Chunk freed.");
}

void edit() {
    int index = getindex();
    if (index < 0 || index >= MAX) {
        puts("Invalid index!");
        _exit(1);
    }
    if (!heaplist[index]) {
        puts("Empty.");
        return;
    }
    printf("Data: ");
    ssize_t len = read(0, heaplist[index], SIZE_SMALL_B);
    faded(heaplist[index], len);
    puts("Chunk edited.");
}

int main() {
    init();
    while(1) {
        menu();
        switch( getnum() ) {
            case 1:
                add();
                break;
            case 2:
                delete();
                break;
            case 3:
                edit();
                break;
            default:
                exit(1);
        }
    }
}
