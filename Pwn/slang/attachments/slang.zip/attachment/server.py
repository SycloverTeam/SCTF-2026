#!/usr/bin/env python3
import os
import random
import string
import subprocess


BUILD_DIR = "/tmp/slang-build"
SHELL_CWD = "/home/ctf"
COMPILER = "/home/ctf/slang"
RUNTIME = "/home/ctf/runtime.c"
MAX_SOURCE = 8192


def rnd(n=12):
    return "".join(random.choice(string.ascii_letters) for _ in range(n))


def build(src):
    os.makedirs(BUILD_DIR, exist_ok=True)
    src_path = os.path.join(BUILD_DIR, rnd() + ".slang")
    c_path = os.path.join(BUILD_DIR, rnd() + ".c")
    exe_path = os.path.join(BUILD_DIR, rnd())
    with open(src_path, "w", encoding="utf-8") as f:
        f.write(src)
    with open(os.devnull, "rb") as devnull:
        if subprocess.run([COMPILER, src_path, c_path], stdin=devnull).returncode != 0:
            return None
        cmd = ["gcc", "-O0", "-Wall", "-Wextra", "-no-pie", "-o", exe_path, c_path, RUNTIME]
        if subprocess.run(cmd, stdin=devnull).returncode != 0:
            return None
    return exe_path


def read_source():
    lines = []
    cur = bytearray()
    while True:
        ch = os.read(0, 1)
        if ch == b"":
            raise EOFError
        if ch == b"\n":
            line = cur.decode("utf-8", errors="strict")
            cur.clear()
            if line == "END_OF_SOURCE":
                return "\n".join(lines)
            lines.append(line)
            if sum(len(x.encode()) + 1 for x in lines) > MAX_SOURCE:
                raise ValueError("source too large")
        else:
            cur += ch


def main():
    print("Give me slang source. End with END_OF_SOURCE.", flush=True)
    try:
        src = read_source()
    except (EOFError, UnicodeDecodeError):
        return 1
    except ValueError as e:
        print(str(e), flush=True)
        return 1
    exe = build(src)
    if not exe:
        print("compilation failed", flush=True)
        return 1
    os.chdir(SHELL_CWD)
    os.chmod(exe, 0o700)
    os.execv(exe, [exe])


if __name__ == "__main__":
    raise SystemExit(main())
