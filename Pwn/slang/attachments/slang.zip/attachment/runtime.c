#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

typedef struct vec_t {
    int64_t *data;
    int64_t size;
} vec_t;

extern int64_t user_main(void);

static void die(const char *msg) {
    fprintf(stderr, "fatal: %s\n", msg);
    exit(1);
}

static void init_io(void) {
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
}

vec_t *rt_vec_new(int64_t n) {
    if (n < 0 || n > 64) {
        die("bad vector size");
    }
    vec_t *v = (vec_t *)malloc(sizeof(vec_t));
    if (!v) {
        die("malloc vec");
    }
    v->data = (int64_t *)calloc((size_t)n, sizeof(int64_t));
    if (n != 0 && !v->data) {
        die("malloc data");
    }
    v->size = n;
    return v;
}

static int64_t vec_load(vec_t *v, int64_t idx) {
    if (!v) {
        die("null vector");
    }
    if (idx < 0 || idx >= v->size) {
        die("vector index out of bounds");
    }
    return v->data[idx];
}

static void vec_store(vec_t *v, int64_t idx, int64_t val) {
    if (!v) {
        die("null vector");
    }
    if (idx < 0 || idx >= v->size) {
        die("vector index out of bounds");
    }
    v->data[idx] = val;
}

void rt_say(const char *s) {
    puts(s);
}

void rt_scribble(vec_t *v, int64_t idx, int64_t delta) {
    vec_store(v, idx, vec_load(v, idx) + delta);
}

void rt_keep_int(int64_t x) {
    asm volatile("" : : "r"(x) : "memory");
}

void rt_keep_str(const char *s) {
    asm volatile("" : : "r"(s) : "memory");
}

void rt_keep_vec(vec_t *v) {
    asm volatile("" : : "r"(v) : "memory");
}

int main(void) {
    init_io();
    alarm(20);
    return (int)user_main();
}
