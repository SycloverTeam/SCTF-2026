#!/bin/sh
set -eu
umask 077
cd /home/ctf
exec python3 /home/ctf/server.py
