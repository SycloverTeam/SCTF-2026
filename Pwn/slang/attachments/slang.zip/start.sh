#!/bin/sh
set -eu

exec /usr/sbin/xinetd -dontfork
