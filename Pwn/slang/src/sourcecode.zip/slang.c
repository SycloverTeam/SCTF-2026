#define _GNU_SOURCE
#include <ctype.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef enum { TY_INT, TY_STR, TY_VEC, TY_VOID, TY_BAD } Type;
typedef enum { TK_ID, TK_NUM, TK_STR, TK_SYM, TK_EOF } TokKind;
typedef enum { E_NUM, E_STR, E_VAR, E_CALL, E_BIN } ExprKind;
typedef enum { S_ASSIGN, S_CALL, S_IF, S_DO, S_RETURN } StmtKind;

typedef struct Expr Expr;
typedef struct Stmt Stmt;

typedef struct {
    TokKind kind;
    char *text;
    int64_t num;
    unsigned char *bytes;
    size_t blen;
    int pos;
} Tok;

typedef struct {
    char *name;
    Type type;
} Decl;

struct Expr {
    ExprKind kind;
    Type type;
    char *name;
    char op[3];
    int64_t num;
    unsigned char *bytes;
    size_t blen;
    Expr **args;
    int nargs;
    Expr *lhs;
    Expr *rhs;
};

struct Stmt {
    StmtKind kind;
    char *name;
    Expr *expr;
    Expr *cond;
    Expr **args;
    int nargs;
    Stmt **body;
    int nbody;
};

typedef struct {
    char *name;
    Decl *params;
    int nparams;
    Decl *locals;
    int nlocals;
    Type ret;
    Stmt **body;
    int nbody;
    int *slots;
    int nslots;
} Func;

typedef struct {
    char *name;
    Type ret;
    Type params[8];
    int nparams;
    int builtin;
} Proto;

typedef struct {
    Tok *v;
    int n;
    int cap;
} TokVec;

typedef struct {
    char **v;
    int n;
    int cap;
} NameVec;

typedef struct {
    char *buf;
    size_t len;
    size_t cap;
} StrBuf;

typedef struct {
    unsigned char **v;
    size_t *len;
    int n;
    int cap;
} StringPool;

typedef struct {
    int start;
    int end;
    int var;
} Interval;

typedef struct {
    int end;
    int slot;
} Active;

typedef struct {
    Func *f;
    int *first;
    int *last;
    int *seen;
    int idx;
} AllocCtx;

static TokVec toks;
static int ti;
static Func **funcs;
static int nfuncs;
static Proto *protos;
static int nprotos;
static StringPool strings;

static void fail(const char *fmt, ...) {
    va_list ap;
    fprintf(stderr, "compile error: ");
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fprintf(stderr, "\n");
    exit(1);
}

static void *xcalloc(size_t n, size_t s) {
    void *p = calloc(n, s);
    if (!p) {
        fail("out of memory");
    }
    return p;
}

static char *xstrdup(const char *s) {
    char *p = strdup(s);
    if (!p) {
        fail("out of memory");
    }
    return p;
}

static char *xstrndup(const char *s, size_t n) {
    char *p = malloc(n + 1);
    if (!p) {
        fail("out of memory");
    }
    memcpy(p, s, n);
    p[n] = 0;
    return p;
}

static void sb_init(StrBuf *b) {
    b->cap = 4096;
    b->len = 0;
    b->buf = xcalloc(b->cap, 1);
}

static void sb_put(StrBuf *b, const char *s) {
    size_t n = strlen(s);
    while (b->len + n + 1 > b->cap) {
        b->cap *= 2;
        b->buf = realloc(b->buf, b->cap);
        if (!b->buf) {
            fail("out of memory");
        }
    }
    memcpy(b->buf + b->len, s, n + 1);
    b->len += n;
}

static void sb_printf(StrBuf *b, const char *fmt, ...) {
    va_list ap;
    char tmp[1024];
    va_start(ap, fmt);
    int n = vsnprintf(tmp, sizeof(tmp), fmt, ap);
    va_end(ap);
    if (n < 0) {
        fail("format error");
    }
    if ((size_t)n < sizeof(tmp)) {
        sb_put(b, tmp);
        return;
    }
    char *big = malloc((size_t)n + 1);
    if (!big) {
        fail("out of memory");
    }
    va_start(ap, fmt);
    vsnprintf(big, (size_t)n + 1, fmt, ap);
    va_end(ap);
    sb_put(b, big);
    free(big);
}

static void toks_push(Tok t) {
    if (toks.n == toks.cap) {
        toks.cap = toks.cap ? toks.cap * 2 : 256;
        toks.v = realloc(toks.v, (size_t)toks.cap * sizeof(Tok));
        if (!toks.v) {
            fail("out of memory");
        }
    }
    toks.v[toks.n++] = t;
}

static int hexval(int c) {
    if ('0' <= c && c <= '9') {
        return c - '0';
    }
    if ('a' <= c && c <= 'f') {
        return c - 'a' + 10;
    }
    if ('A' <= c && c <= 'F') {
        return c - 'A' + 10;
    }
    return -1;
}

static void lex(const char *src) {
    int i = 0;
    while (src[i]) {
        if (isspace((unsigned char)src[i])) {
            i++;
            continue;
        }
        if (src[i] == '#') {
            while (src[i] && src[i] != '\n') {
                i++;
            }
            continue;
        }
        if (src[i] == '"') {
            int start = i++;
            size_t cap = 32, n = 0;
            unsigned char *buf = malloc(cap);
            if (!buf) {
                fail("out of memory");
            }
            while (src[i] && src[i] != '"') {
                unsigned char c;
                if (src[i] == '\\') {
                    i++;
                    if (src[i] == 'x') {
                        int a = hexval(src[i + 1]);
                        int b = hexval(src[i + 2]);
                        if (a < 0 || b < 0) {
                            fail("bad string literal");
                        }
                        c = (unsigned char)((a << 4) | b);
                        i += 3;
                    } else if (src[i] == 'n') {
                        c = '\n';
                        i++;
                    } else if (src[i] == 't') {
                        c = '\t';
                        i++;
                    } else {
                        c = (unsigned char)src[i++];
                    }
                } else {
                    c = (unsigned char)src[i++];
                }
                if (n == cap) {
                    cap *= 2;
                    buf = realloc(buf, cap);
                    if (!buf) {
                        fail("out of memory");
                    }
                }
                buf[n++] = c;
            }
            if (src[i] != '"') {
                fail("unterminated string");
            }
            i++;
            toks_push((Tok){TK_STR, NULL, 0, buf, n, start});
            continue;
        }
        if (isdigit((unsigned char)src[i]) || (src[i] == '-' && isdigit((unsigned char)src[i + 1]))) {
            int start = i;
            if (src[i] == '-') {
                i++;
            }
            if (src[i] == '0' && (src[i + 1] == 'x' || src[i + 1] == 'X')) {
                i += 2;
                while (isxdigit((unsigned char)src[i])) {
                    i++;
                }
            } else {
                while (isdigit((unsigned char)src[i])) {
                    i++;
                }
            }
            char *s = xstrndup(src + start, (size_t)(i - start));
            toks_push((Tok){TK_NUM, s, strtoll(s, NULL, 0), NULL, 0, start});
            continue;
        }
        if (isalpha((unsigned char)src[i]) || src[i] == '_') {
            int start = i++;
            while (isalnum((unsigned char)src[i]) || src[i] == '_') {
                i++;
            }
            toks_push((Tok){TK_ID, xstrndup(src + start, (size_t)(i - start)), 0, NULL, 0, start});
            continue;
        }
        int start = i;
        if ((src[i] == ':' && src[i + 1] == '=') || (src[i] == '-' && src[i + 1] == '>') ||
            (src[i] == '=' && src[i + 1] == '=') || (src[i] == '<' && src[i + 1] == '=') ||
            (src[i] == '>' && src[i + 1] == '=')) {
            toks_push((Tok){TK_SYM, xstrndup(src + i, 2), 0, NULL, 0, start});
            i += 2;
        } else if (strchr("+-*<>{}();,:", src[i])) {
            toks_push((Tok){TK_SYM, xstrndup(src + i, 1), 0, NULL, 0, start});
            i++;
        } else {
            fail("unexpected byte %d", i);
        }
    }
    toks_push((Tok){TK_EOF, xstrdup(""), 0, NULL, 0, (int)strlen(src)});
}

static Tok *peek(void) {
    return &toks.v[ti];
}

static int is_tok(const char *s) {
    return peek()->text && strcmp(peek()->text, s) == 0;
}

static Tok *take_kind(TokKind k) {
    Tok *t = peek();
    if (t->kind != k) {
        fail("unexpected token at byte %d", t->pos);
    }
    ti++;
    return t;
}

static void take(const char *s) {
    if (!is_tok(s)) {
        fail("expected %s at byte %d", s, peek()->pos);
    }
    ti++;
}

static Type parse_type(int allow_void) {
    char *s = take_kind(TK_ID)->text;
    if (strcmp(s, "int") == 0) {
        return TY_INT;
    }
    if (strcmp(s, "str") == 0) {
        return TY_STR;
    }
    if (strcmp(s, "vec") == 0) {
        return TY_VEC;
    }
    if (allow_void && strcmp(s, "void") == 0) {
        return TY_VOID;
    }
    fail("bad type %s", s);
    return TY_BAD;
}

static Expr *parse_expr(void);
static Stmt **parse_block(int *nout);

static Expr *new_expr(ExprKind k) {
    Expr *e = xcalloc(1, sizeof(Expr));
    e->kind = k;
    e->type = TY_BAD;
    return e;
}

static Stmt *new_stmt(StmtKind k) {
    Stmt *s = xcalloc(1, sizeof(Stmt));
    s->kind = k;
    return s;
}

static Decl *parse_decls_until(const char *stop, int *nout) {
    Decl *items = NULL;
    int n = 0, cap = 0;
    if (is_tok(stop)) {
        *nout = 0;
        return NULL;
    }
    for (;;) {
        if (n == cap) {
            cap = cap ? cap * 2 : 4;
            items = realloc(items, (size_t)cap * sizeof(Decl));
            if (!items) {
                fail("out of memory");
            }
        }
        items[n].type = parse_type(0);
        items[n].name = xstrdup(take_kind(TK_ID)->text);
        n++;
        if (!is_tok(",")) {
            break;
        }
        take(",");
    }
    *nout = n;
    return items;
}

static Expr **parse_args(int *nout) {
    Expr **args = NULL;
    int n = 0, cap = 0;
    if (is_tok(")")) {
        *nout = 0;
        return NULL;
    }
    for (;;) {
        if (n == cap) {
            cap = cap ? cap * 2 : 4;
            args = realloc(args, (size_t)cap * sizeof(Expr *));
            if (!args) {
                fail("out of memory");
            }
        }
        args[n++] = parse_expr();
        if (!is_tok(",")) {
            break;
        }
        take(",");
    }
    *nout = n;
    return args;
}

static Expr *parse_term(void) {
    Tok *t = peek();
    if (t->kind == TK_NUM) {
        Expr *e = new_expr(E_NUM);
        e->num = take_kind(TK_NUM)->num;
        return e;
    }
    if (t->kind == TK_STR) {
        Expr *e = new_expr(E_STR);
        Tok *s = take_kind(TK_STR);
        e->bytes = s->bytes;
        e->blen = s->blen;
        return e;
    }
    if (is_tok("(")) {
        take("(");
        Expr *e = parse_expr();
        take(")");
        return e;
    }
    char *name = xstrdup(take_kind(TK_ID)->text);
    if (is_tok("(")) {
        Expr *e = new_expr(E_CALL);
        e->name = name;
        take("(");
        e->args = parse_args(&e->nargs);
        take(")");
        return e;
    }
    Expr *e = new_expr(E_VAR);
    e->name = name;
    return e;
}

static Expr *parse_add(void) {
    Expr *e = parse_term();
    while (is_tok("+") || is_tok("-")) {
        Expr *b = new_expr(E_BIN);
        snprintf(b->op, sizeof(b->op), "%s", peek()->text);
        ti++;
        b->lhs = e;
        b->rhs = parse_term();
        e = b;
    }
    return e;
}

static Expr *parse_expr(void) {
    Expr *e = parse_add();
    while (is_tok("==") || is_tok("<") || is_tok("<=") || is_tok(">=")) {
        Expr *b = new_expr(E_BIN);
        snprintf(b->op, sizeof(b->op), "%s", peek()->text);
        ti++;
        b->lhs = e;
        b->rhs = parse_add();
        e = b;
    }
    return e;
}

static Stmt *parse_stmt(void) {
    if (is_tok("if")) {
        Stmt *s = new_stmt(S_IF);
        take("if");
        take("(");
        s->cond = parse_expr();
        take(")");
        s->body = parse_block(&s->nbody);
        return s;
    }
    if (is_tok("do")) {
        Stmt *s = new_stmt(S_DO);
        take("do");
        s->body = parse_block(&s->nbody);
        take("while");
        take("(");
        s->cond = parse_expr();
        take(")");
        take(";");
        return s;
    }
    if (is_tok("return")) {
        Stmt *s = new_stmt(S_RETURN);
        take("return");
        if (is_tok(";")) {
            take(";");
            return s;
        }
        s->expr = parse_expr();
        take(";");
        return s;
    }
    char *name = xstrdup(take_kind(TK_ID)->text);
    if (is_tok(":=")) {
        Stmt *s = new_stmt(S_ASSIGN);
        s->name = name;
        take(":=");
        s->expr = parse_expr();
        take(";");
        return s;
    }
    Stmt *s = new_stmt(S_CALL);
    s->name = name;
    take("(");
    s->args = parse_args(&s->nargs);
    take(")");
    take(";");
    return s;
}

static Stmt **parse_block(int *nout) {
    Stmt **body = NULL;
    int n = 0, cap = 0;
    take("{");
    while (!is_tok("}")) {
        if (n == cap) {
            cap = cap ? cap * 2 : 8;
            body = realloc(body, (size_t)cap * sizeof(Stmt *));
            if (!body) {
                fail("out of memory");
            }
        }
        body[n++] = parse_stmt();
    }
    take("}");
    if (is_tok(";")) {
        take(";");
    }
    *nout = n;
    return body;
}

static Func *parse_func(void) {
    Func *f = xcalloc(1, sizeof(Func));
    take("function");
    f->name = xstrdup(take_kind(TK_ID)->text);
    take("(");
    f->params = parse_decls_until(")", &f->nparams);
    take(")");
    take(":");
    f->locals = parse_decls_until("->", &f->nlocals);
    take("->");
    f->ret = parse_type(1);
    f->body = parse_block(&f->nbody);
    return f;
}

static void parse_module(void) {
    while (peek()->kind != TK_EOF) {
        funcs = realloc(funcs, (size_t)(nfuncs + 1) * sizeof(Func *));
        if (!funcs) {
            fail("out of memory");
        }
        funcs[nfuncs++] = parse_func();
    }
}

static void add_proto(const char *name, Type ret, Type *params, int n, int builtin) {
    protos = realloc(protos, (size_t)(nprotos + 1) * sizeof(Proto));
    if (!protos) {
        fail("out of memory");
    }
    Proto *p = &protos[nprotos++];
    p->name = xstrdup(name);
    p->ret = ret;
    p->nparams = n;
    p->builtin = builtin;
    for (int i = 0; i < n; i++) {
        p->params[i] = params[i];
    }
}

static Proto *find_proto(const char *name) {
    for (int i = 0; i < nprotos; i++) {
        if (strcmp(protos[i].name, name) == 0) {
            return &protos[i];
        }
    }
    return NULL;
}

static Func *find_func(const char *name) {
    for (int i = 0; i < nfuncs; i++) {
        if (strcmp(funcs[i]->name, name) == 0) {
            return funcs[i];
        }
    }
    return NULL;
}

static Type env_lookup(Func *f, const char *name) {
    for (int i = 0; i < f->nparams; i++) {
        if (strcmp(f->params[i].name, name) == 0) {
            return f->params[i].type;
        }
    }
    for (int i = 0; i < f->nlocals; i++) {
        if (strcmp(f->locals[i].name, name) == 0) {
            return f->locals[i].type;
        }
    }
    return TY_BAD;
}

static int local_index(Func *f, const char *name) {
    int idx = 0;
    for (int i = 0; i < f->nparams; i++, idx++) {
        if (strcmp(f->params[i].name, name) == 0) {
            return idx;
        }
    }
    for (int i = 0; i < f->nlocals; i++, idx++) {
        if (strcmp(f->locals[i].name, name) == 0) {
            return idx;
        }
    }
    return -1;
}

static Type check_expr(Func *f, Expr *e);

static Type check_call(Func *f, const char *name, Expr **args, int nargs) {
    Proto *p = find_proto(name);
    if (!p) {
        fail("unknown function %s", name);
    }
    if (nargs != p->nparams) {
        fail("%s expects %d args", name, p->nparams);
    }
    for (int i = 0; i < nargs; i++) {
        Type got = check_expr(f, args[i]);
        if (got != p->params[i]) {
            fail("%s argument type mismatch", name);
        }
    }
    return p->ret;
}

static Type check_expr(Func *f, Expr *e) {
    if (e->kind == E_NUM) {
        return e->type = TY_INT;
    }
    if (e->kind == E_STR) {
        return e->type = TY_STR;
    }
    if (e->kind == E_VAR) {
        Type t = env_lookup(f, e->name);
        if (t == TY_BAD) {
            fail("undefined variable %s", e->name);
        }
        return e->type = t;
    }
    if (e->kind == E_BIN) {
        if (check_expr(f, e->lhs) != TY_INT || check_expr(f, e->rhs) != TY_INT) {
            fail("binary operands must be int");
        }
        return e->type = TY_INT;
    }
    if (e->kind == E_CALL) {
        return e->type = check_call(f, e->name, e->args, e->nargs);
    }
    fail("internal type error");
    return TY_BAD;
}

static void check_stmt(Func *f, Stmt *s) {
    if (s->kind == S_ASSIGN) {
        Type dst = env_lookup(f, s->name);
        if (dst == TY_BAD) {
            fail("undefined variable %s", s->name);
        }
        if (check_expr(f, s->expr) != dst) {
            fail("assignment type mismatch");
        }
    } else if (s->kind == S_CALL) {
        if (check_call(f, s->name, s->args, s->nargs) != TY_VOID) {
            fail("non-void call as statement");
        }
    } else if (s->kind == S_IF) {
        if (check_expr(f, s->cond) != TY_INT) {
            fail("if condition must be int");
        }
        for (int i = 0; i < s->nbody; i++) {
            check_stmt(f, s->body[i]);
        }
    } else if (s->kind == S_DO) {
        for (int i = 0; i < s->nbody; i++) {
            check_stmt(f, s->body[i]);
        }
        if (check_expr(f, s->cond) != TY_INT) {
            fail("while condition must be int");
        }
    } else if (s->kind == S_RETURN) {
        if (!s->expr) {
            if (f->ret != TY_VOID) {
                fail("missing return value");
            }
        } else if (check_expr(f, s->expr) != f->ret) {
            fail("return type mismatch");
        }
    }
}

static void typecheck(void) {
    Type p[3];
    p[0] = TY_INT;
    add_proto("vec_new", TY_VEC, p, 1, 1);
    p[0] = TY_STR;
    add_proto("say", TY_VOID, p, 1, 1);
    p[0] = TY_VEC;
    p[1] = TY_INT;
    p[2] = TY_INT;
    add_proto("scribble", TY_VOID, p, 3, 1);
    p[0] = TY_INT;
    add_proto("keep_int", TY_VOID, p, 1, 1);
    p[0] = TY_STR;
    add_proto("keep_str", TY_VOID, p, 1, 1);
    p[0] = TY_VEC;
    add_proto("keep_vec", TY_VOID, p, 1, 1);

    for (int i = 0; i < nfuncs; i++) {
        Func *f = funcs[i];
        if (find_proto(f->name)) {
            fail("function %s shadows builtin", f->name);
        }
        Type params[8];
        if (f->nparams > 8) {
            fail("too many params");
        }
        for (int j = 0; j < f->nparams; j++) {
            params[j] = f->params[j].type;
        }
        add_proto(f->name, f->ret, params, f->nparams, 0);
    }
    Func *mainf = find_func("main");
    if (!mainf || mainf->nparams || mainf->ret != TY_INT) {
        fail("bad main");
    }
    for (int i = 0; i < nfuncs; i++) {
        Func *f = funcs[i];
        for (int a = 0; a < f->nparams; a++) {
            for (int b = a + 1; b < f->nparams; b++) {
                if (strcmp(f->params[a].name, f->params[b].name) == 0) {
                    fail("duplicate variable");
                }
            }
            for (int b = 0; b < f->nlocals; b++) {
                if (strcmp(f->params[a].name, f->locals[b].name) == 0) {
                    fail("duplicate variable");
                }
            }
        }
        for (int a = 0; a < f->nlocals; a++) {
            for (int b = a + 1; b < f->nlocals; b++) {
                if (strcmp(f->locals[a].name, f->locals[b].name) == 0) {
                    fail("duplicate variable");
                }
            }
        }
        for (int j = 0; j < f->nbody; j++) {
            check_stmt(f, f->body[j]);
        }
    }
}

static void names_push(NameVec *v, const char *name) {
    if (v->n == v->cap) {
        v->cap = v->cap ? v->cap * 2 : 8;
        v->v = realloc(v->v, (size_t)v->cap * sizeof(char *));
        if (!v->v) {
            fail("out of memory");
        }
    }
    v->v[v->n++] = (char *)name;
}

static void collect_uses(Expr *e, NameVec *v) {
    if (!e) {
        return;
    }
    if (e->kind == E_VAR) {
        names_push(v, e->name);
    } else if (e->kind == E_BIN) {
        collect_uses(e->lhs, v);
        collect_uses(e->rhs, v);
    } else if (e->kind == E_CALL) {
        for (int i = 0; i < e->nargs; i++) {
            collect_uses(e->args[i], v);
        }
    }
}

static int interval_cmp(const void *ap, const void *bp) {
    const Interval *a = ap;
    const Interval *b = bp;
    if (a->start != b->start) {
        return a->start - b->start;
    }
    if (a->end != b->end) {
        return a->end - b->end;
    }
    return a->var - b->var;
}

static void alloc_use_name(AllocCtx *ctx, const char *name, int at) {
    int i = local_index(ctx->f, name);
    if (i >= 0 && ctx->seen[i] && ctx->last[i] < at) {
        ctx->last[i] = at;
    }
}

static void alloc_scan_expr(AllocCtx *ctx, Expr *e, int at) {
    NameVec uses = {0};
    collect_uses(e, &uses);
    for (int i = 0; i < uses.n; i++) {
        alloc_use_name(ctx, uses.v[i], at);
    }
    free(uses.v);
}

static void alloc_scan_block(AllocCtx *ctx, Stmt **body, int nbody, int in_loop);

static void alloc_scan_stmt(AllocCtx *ctx, Stmt *s, int in_loop) {
    int at = ctx->idx++;
    if (s->kind == S_ASSIGN) {
        int vi = local_index(ctx->f, s->name);
        if (vi >= 0 && !ctx->seen[vi]) {
            ctx->seen[vi] = 1;
            ctx->first[vi] = at;
            ctx->last[vi] = at;
        } else if (vi >= 0 && ctx->last[vi] < at) {
            ctx->last[vi] = at;
        }
        alloc_scan_expr(ctx, s->expr, at);
    } else if (s->kind == S_CALL) {
        Proto *p = find_proto(s->name);
        if (!(in_loop && p && p->ret == TY_VOID)) {
            for (int i = 0; i < s->nargs; i++) {
                alloc_scan_expr(ctx, s->args[i], at);
            }
        }
    } else if (s->kind == S_IF) {
        alloc_scan_expr(ctx, s->cond, at);
        alloc_scan_block(ctx, s->body, s->nbody, in_loop);
    } else if (s->kind == S_DO) {
        alloc_scan_block(ctx, s->body, s->nbody, 1);
        alloc_scan_expr(ctx, s->cond, ctx->idx);
        ctx->idx++;
    } else if (s->kind == S_RETURN) {
        alloc_scan_expr(ctx, s->expr, at);
    }
}

static void alloc_scan_block(AllocCtx *ctx, Stmt **body, int nbody, int in_loop) {
    for (int i = 0; i < nbody; i++) {
        alloc_scan_stmt(ctx, body[i], in_loop);
    }
}

static void allocate_slots(Func *f) {
    int nvars = f->nparams + f->nlocals;
    int *first = xcalloc((size_t)nvars, sizeof(int));
    int *last = xcalloc((size_t)nvars, sizeof(int));
    int *seen = xcalloc((size_t)nvars, sizeof(int));
    for (int i = 0; i < f->nparams; i++) {
        seen[i] = 1;
    }
    AllocCtx ctx = {f, first, last, seen, 1};
    alloc_scan_block(&ctx, f->body, f->nbody, 0);

    Interval *ints = xcalloc((size_t)nvars, sizeof(Interval));
    int nints = 0;
    for (int i = 0; i < nvars; i++) {
        if (seen[i]) {
            ints[nints++] = (Interval){first[i], last[i], i};
        }
    }
    qsort(ints, (size_t)nints, sizeof(Interval), interval_cmp);

    int *free_slots = xcalloc((size_t)nvars, sizeof(int));
    int nfree = 0;
    Active *active = xcalloc((size_t)nvars, sizeof(Active));
    int nactive = 0;
    int next_slot = 0;
    f->slots = xcalloc((size_t)nvars, sizeof(int));
    for (int i = 0; i < nvars; i++) {
        f->slots[i] = -1;
    }

    for (int i = 0; i < nints; i++) {
        Active *kept = xcalloc((size_t)nvars, sizeof(Active));
        int nkept = 0;
        for (int j = 0; j < nactive; j++) {
            if (active[j].end < ints[i].start) {
                free_slots[nfree++] = active[j].slot;
            } else {
                kept[nkept++] = active[j];
            }
        }
        memcpy(active, kept, (size_t)nkept * sizeof(Active));
        free(kept);
        nactive = nkept;

        int slot;
        if (nfree) {
            int best = 0;
            for (int j = 1; j < nfree; j++) {
                if (free_slots[j] < free_slots[best]) {
                    best = j;
                }
            }
            slot = free_slots[best];
            free_slots[best] = free_slots[--nfree];
        } else {
            slot = next_slot++;
        }
        f->slots[ints[i].var] = slot;
        active[nactive++] = (Active){ints[i].end, slot};
    }
    f->nslots = next_slot ? next_slot : 1;
}

static int pool_add(unsigned char *bytes, size_t len) {
    if (strings.n == strings.cap) {
        strings.cap = strings.cap ? strings.cap * 2 : 16;
        strings.v = realloc(strings.v, (size_t)strings.cap * sizeof(unsigned char *));
        strings.len = realloc(strings.len, (size_t)strings.cap * sizeof(size_t));
        if (!strings.v || !strings.len) {
            fail("out of memory");
        }
    }
    strings.v[strings.n] = bytes;
    strings.len[strings.n] = len;
    return strings.n++;
}

static char *cexpr(Func *f, Expr *e);

static const char *cast_name(Type t) {
    if (t == TY_STR) {
        return "const char*";
    }
    if (t == TY_VEC) {
        return "vec_t*";
    }
    return "int64_t";
}

static char *cast_expr(Func *f, Expr *e, Type t) {
    char *inner = cexpr(f, e);
    StrBuf b;
    sb_init(&b);
    sb_printf(&b, "((%s)%s)", cast_name(t), inner);
    free(inner);
    return b.buf;
}

static char *cexpr(Func *f, Expr *e) {
    StrBuf b;
    sb_init(&b);
    if (e->kind == E_NUM) {
        sb_printf(&b, "((uintptr_t)%lld)", (long long)e->num);
    } else if (e->kind == E_STR) {
        sb_printf(&b, "((uintptr_t)S%d)", pool_add(e->bytes, e->blen));
    } else if (e->kind == E_VAR) {
        int vi = local_index(f, e->name);
        if (vi < 0 || !f->slots || f->slots[vi] < 0) {
            fail("bad slot for %s", e->name);
        }
        sb_printf(&b, "slot[%d]", f->slots[vi]);
    } else if (e->kind == E_BIN) {
        char *lhs = cexpr(f, e->lhs);
        char *rhs = cexpr(f, e->rhs);
        sb_printf(&b, "((uintptr_t)(((int64_t)%s) %s ((int64_t)%s)))", lhs, e->op, rhs);
        free(lhs);
        free(rhs);
    } else if (e->kind == E_CALL) {
        Proto *p = find_proto(e->name);
        if (strcmp(e->name, "vec_new") == 0) {
            char *arg = cast_expr(f, e->args[0], TY_INT);
            sb_printf(&b, "((uintptr_t)rt_vec_new(%s))", arg);
            free(arg);
        } else if (p && p->builtin) {
            fail("builtin is not an expression");
        } else {
            sb_printf(&b, "F_%s(", e->name);
            for (int i = 0; i < e->nargs; i++) {
                char *arg = cexpr(f, e->args[i]);
                if (i) {
                    sb_put(&b, ", ");
                }
                sb_put(&b, arg);
                free(arg);
            }
            sb_put(&b, ")");
        }
    }
    return b.buf;
}

static void emit_stmt(StrBuf *b, Func *f, Stmt *s, const char *ind);

static void emit_call_stmt(StrBuf *b, Func *f, Stmt *s, const char *ind) {
    Proto *p = find_proto(s->name);
    if (strcmp(s->name, "say") == 0) {
        char *a = cast_expr(f, s->args[0], TY_STR);
        sb_printf(b, "%srt_say(%s);\n", ind, a);
        free(a);
    } else if (strcmp(s->name, "scribble") == 0) {
        char *a = cast_expr(f, s->args[0], TY_VEC);
        char *i = cast_expr(f, s->args[1], TY_INT);
        char *d = cast_expr(f, s->args[2], TY_INT);
        sb_printf(b, "%srt_scribble(%s, %s, %s);\n", ind, a, i, d);
        free(a);
        free(i);
        free(d);
    } else if (strcmp(s->name, "keep_int") == 0 || strcmp(s->name, "keep_str") == 0 || strcmp(s->name, "keep_vec") == 0) {
        char *a = cast_expr(f, s->args[0], p->params[0]);
        const char *rt = strcmp(s->name, "keep_int") == 0 ? "rt_keep_int" : strcmp(s->name, "keep_str") == 0 ? "rt_keep_str" : "rt_keep_vec";
        sb_printf(b, "%s%s(%s);\n", ind, rt, a);
        free(a);
    } else {
        sb_printf(b, "%s(void)F_%s(", ind, s->name);
        for (int i = 0; i < s->nargs; i++) {
            char *a = cexpr(f, s->args[i]);
            if (i) {
                sb_put(b, ", ");
            }
            sb_put(b, a);
            free(a);
        }
        sb_put(b, ");\n");
    }
}

static void emit_stmt(StrBuf *b, Func *f, Stmt *s, const char *ind) {
    if (s->kind == S_ASSIGN) {
        int vi = local_index(f, s->name);
        char *e = cexpr(f, s->expr);
        sb_printf(b, "%sslot[%d] = %s;\n", ind, f->slots[vi], e);
        free(e);
    } else if (s->kind == S_CALL) {
        emit_call_stmt(b, f, s, ind);
    } else if (s->kind == S_IF) {
        char *c = cexpr(f, s->cond);
        sb_printf(b, "%sif ((int64_t)%s) {\n", ind, c);
        free(c);
        for (int i = 0; i < s->nbody; i++) {
            emit_stmt(b, f, s->body[i], "    ");
        }
        sb_printf(b, "%s}\n", ind);
    } else if (s->kind == S_DO) {
        sb_printf(b, "%sdo {\n", ind);
        for (int i = 0; i < s->nbody; i++) {
            emit_stmt(b, f, s->body[i], "    ");
        }
        char *c = cexpr(f, s->cond);
        sb_printf(b, "%s} while ((int64_t)%s);\n", ind, c);
        free(c);
    } else if (s->kind == S_RETURN) {
        if (!s->expr) {
            sb_printf(b, "%sreturn 0;\n", ind);
        } else {
            char *e = cexpr(f, s->expr);
            sb_printf(b, "%sreturn %s;\n", ind, e);
            free(e);
        }
    }
}

static void emit_function(StrBuf *b, Func *f) {
    sb_printf(b, "static uintptr_t F_%s(", f->name);
    for (int i = 0; i < f->nparams; i++) {
        if (i) {
            sb_put(b, ", ");
        }
        sb_printf(b, "uintptr_t p%d", i);
    }
    sb_put(b, ") {\n");
    sb_printf(b, "  uintptr_t slot[%d] = {0};\n  (void)slot;\n", f->nslots);
    for (int i = 0; i < f->nparams; i++) {
        sb_printf(b, "  slot[%d] = p%d;\n", f->slots[i], i);
    }
    for (int i = 0; i < f->nbody; i++) {
        emit_stmt(b, f, f->body[i], "  ");
    }
    sb_put(b, "  return 0;\n}\n\n");
}

static char *emit_c(void) {
    StrBuf bodies;
    sb_init(&bodies);
    for (int i = 0; i < nfuncs; i++) {
        emit_function(&bodies, funcs[i]);
    }

    StrBuf out;
    sb_init(&out);
    sb_put(&out,
        "#include <stdint.h>\n#include <stddef.h>\n"
        "typedef struct vec_t vec_t;\n"
        "extern vec_t* rt_vec_new(int64_t n);\n"
        "extern void rt_say(const char* s);\n"
        "extern void rt_scribble(vec_t* v, int64_t idx, int64_t delta);\n"
        "extern void rt_keep_int(int64_t x);\n"
        "extern void rt_keep_str(const char* s);\n"
        "extern void rt_keep_vec(vec_t* v);\n\n");
    for (int i = 0; i < strings.n; i++) {
        sb_printf(&out, "static unsigned char S%d[] = { ", i);
        for (size_t j = 0; j < strings.len[i]; j++) {
            sb_printf(&out, "%u, ", strings.v[i][j]);
        }
        sb_put(&out, "0 };\n");
    }
    sb_put(&out, "\n");
    for (int i = 0; i < nfuncs; i++) {
        Func *f = funcs[i];
        sb_printf(&out, "static uintptr_t F_%s(", f->name);
        for (int j = 0; j < f->nparams; j++) {
            if (j) {
                sb_put(&out, ", ");
            }
            sb_printf(&out, "uintptr_t p%d", j);
        }
        sb_put(&out, ");\n");
    }
    sb_put(&out, "\n");
    sb_put(&out, bodies.buf);
    sb_put(&out, "int64_t user_main(void) { return (int64_t)F_main(); }\n");
    return out.buf;
}

static char *read_file(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) {
        fail("cannot open source");
    }
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    fseek(f, 0, SEEK_SET);
    char *buf = xcalloc((size_t)n + 1, 1);
    if (fread(buf, 1, (size_t)n, f) != (size_t)n) {
        fail("read source failed");
    }
    fclose(f);
    return buf;
}

int main(int argc, char **argv) {
    if (argc != 3) {
        fprintf(stderr, "usage: %s source.slang output.c\n", argv[0]);
        return 2;
    }
    char *src = read_file(argv[1]);
    lex(src);
    parse_module();
    typecheck();
    for (int i = 0; i < nfuncs; i++) {
        allocate_slots(funcs[i]);
    }
    char *c = emit_c();
    FILE *out = fopen(argv[2], "wb");
    if (!out) {
        fail("cannot open output");
    }
    fwrite(c, 1, strlen(c), out);
    fclose(out);
    return 0;
}
